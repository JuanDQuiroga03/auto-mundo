package entidades; // Define el paquete en el que se encuentra la clase

import java.sql.Array;



public class Categoria { // Declaración de la clase Categoria
    private int id; // Identificador único de la categoría
    private String nombre; // Nombre de la categoría
    private String correo; // Correo asociado a la categoría
    private String contraseña; // Contraseña para autenticación (mal manejo, debería ser encriptada)
    private String rol; // Rol del usuario dentro de la categoría
    private boolean activos; // Indica si la categoría está activa o no

    // Constructor de la clase que inicializa todos los atributos
    public Categoria(int id, String nombre, String correo, String contraseña, String array, boolean activos) {
        this.id = id; // Asigna el valor del parámetro id al atributo de la clase
        this.nombre = nombre; // Asigna el valor del parámetro nombre al atributo de la clase
        this.correo = correo; // Asigna el valor del parámetro correo al atributo de la clase
        this.contraseña = contraseña; // Almacena la contraseña en texto plano, lo cual no es seguro
        this.rol = rol; // Asigna el rol al atributo de la clase
        this.activos = activos; // Asigna el valor del parámetro activos al atributo de la clase
    }

    public Categoria(int aInt, String string, String string0, String string1, Array array) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Categoria() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Métodos setters para modificar los atributos de la clase
    public void setId(int id) { // Método para establecer el valor del atributo id
        this.id = id; // Asigna el nuevo valor al atributo id
    }

    public void setNombre(String nombre) { // Método para establecer el valor del atributo nombre
        this.nombre = nombre; // Asigna el nuevo valor al atributo nombre
    }

    public void setCorreo(String correo) { // Método para establecer el valor del atributo correo
        this.correo = correo; // Asigna el nuevo valor al atributo correo
    }

    public void setContraseña(String contraseña) { // Método para establecer la contraseña
        this.contraseña = contraseña; // Debe considerarse encriptación para mayor seguridad
    }

    public void setRol(String rol) { // Método para establecer el rol
        this.rol = rol; // Asigna el nuevo valor al atributo rol
    }

    public void setActivos(boolean activos) { // Método para establecer si la categoría está activa o no
        this.activos = activos; // Asigna el nuevo valor al atributo activos
    }

    // Métodos getters para obtener los valores de los atributos
    public int getId() { // Método para obtener el id de la categoría
        return id; // Retorna el valor del atributo id
    }

    public String getNombre() { // Método para obtener el nombre de la categoría
        return nombre; // Retorna el valor del atributo nombre
    }

    public String getCorreo() { // Método para obtener el correo de la categoría
        return correo; // Retorna el valor del atributo correo
    }

    public String getContraseña() { // Método para obtener la contraseña (no recomendado devolverla en texto plano)
        return contraseña; // Riesgoso devolver contraseñas en texto plano
    }

    public String getRol() { // Método para obtener el rol de la categoría
        return rol; // Retorna el valor del atributo rol
    }

    public boolean isActivos() { // Método para verificar si la categoría está activa (nombre incorrecto, debería ser isActivo)
        return activos; // Retorna el valor del atributo activos
    }

    public boolean isActivo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getDescripcion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setDescripcion(String descripcion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}